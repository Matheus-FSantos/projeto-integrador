package br.com.senacsp.projetointegrador;

public class LogisticaApplication {

	public static void main(String[] args) {
		new App().init();
	}
	
}
